import os
  # accessible as a variable in index.html:
from sqlalchemy import *
from sqlalchemy.pool import NullPool
from flask import Flask, request, render_template, g, redirect, Response

#tmpl_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
tmpl_dir = "./templates"
app = Flask(__name__, template_folder=tmpl_dir)

DATABASE_USERNAME = "yc4387"
DATABASE_PASSWRD = "221558"
DATABASE_HOST ="35.212.75.104"
#DATABASE_HOST = "34.148.107.47" 
#DATABASE_HOST = "34.28.53.86"# change to 34.28.53.86 if you used database 2 for part 2
DATABASEURI = f"postgresql://{DATABASE_USERNAME}:{DATABASE_PASSWRD}@{DATABASE_HOST}/proj1part2"


#
# This line creates a database engine that knows how to connect to the URI above.
#
engine = create_engine(DATABASEURI)



@app.before_request
def before_request():
	"""
	This function is run at the beginning of every web request 
	(every time you enter an address in the web browser).
	We use it to setup a database connection that can be used throughout the request.

	The variable g is globally accessible.
	"""
	try:
		g.conn = engine.connect()
	except:
		print("uh oh, problem connecting to database")
		import traceback; traceback.print_exc()
		g.conn = None


@app.teardown_request
def teardown_request(exception):
	"""
	At the end of the web request, this makes sure to close the database connection.
	If you don't, the database could run out of memory!
	"""
	try:
		g.conn.close()
	except Exception as e:
		pass
	

@app.route('/find_developer_games', methods=['POST'])
def find_developer_games():
    developer_name = request.form['developer_name']
    positive_rate = float(request.form['positive_rate_requirement'])*0.01
    
    if developer_name:
        if positive_rate:  # if user provides positive_rate, construct a query with the condition
            developer_games_query = """
            SELECT g.Game_Title, g.Genre, g.Original_Price, g.Current_Price, g.Positive_ratings_percentage, d.Developer_name, d.Website
                FROM ONLY Games g
                JOIN Games_Developers gd ON g.Game_id = gd.Game_id
                JOIN Developers d ON gd.Developer_id = d.Developer_id
                WHERE g.Positive_ratings_percentage >= :positive_rate
                AND d.Developer_name = :developer_name;
            """
            cursor = g.conn.execute(text(developer_games_query), {'developer_name': developer_name, 'positive_rate': positive_rate})
        else:  # if user does not provide any requirements of positive_rate, construct a query without the condition
            developer_games_query = """
            SELECT g.Game_Title, g.Genre, g.Original_Price, g.Current_Price, g.Positive_ratings_percentage, d.Developer_name, d.Website
                FROM ONLY Games g
                JOIN Games_Developers gd ON g.Game_id = gd.Game_id
                JOIN Developers d ON gd.Developer_id = d.Developer_id
                WHERE d.Developer_name = :developer_name;
            """
            cursor = g.conn.execute(text(developer_games_query), {'developer_name': developer_name})
			
        developer_games = cursor.fetchall()
        cursor.close()
        return render_template("developer_games.html", developer_games=developer_games)
    return redirect('/')


@app.route('/find_multiple_search_games', methods=['GET','POST'])
def multiple_search():
    derivative_pref = request.form['derivative']
    storage = float(request.form['storage'])  # Assume the storage is already in GB
    budget = float(request.form['budget'])


    if (budget is not None) and (storage is not None):

        base_query = """
        SELECT g.Game_Title, g.Genre, g.Average_Rate_Type, g.Current_Price, g.Discount, sr.Storage
		FROM ONLY Games g
		JOIN System_Requirement sr ON g.Game_id = sr.Game_id
		""" 

        derivative_clause = "WHERE g.Current_Price <= :budget"
        if derivative_pref == "yes":
            derivative_clause = """
			JOIN Derivative_games dg ON g.Game_id = dg.Game_id 
			WHERE g.Current_Price <= :budget
		"""
        elif derivative_pref == "no":
            derivative_clause = """
			LEFT JOIN Derivative_games dg ON g.Game_id = dg.Game_id 
			WHERE dg.Game_id IS NULL 
			AND g.Current_Price <= :budget
			"""

        storage_clause ="""
			AND sr.Storage != 'NULL'
			AND(
				CASE
					WHEN sr.Storage LIKE '%% MB %%' THEN CAST(REPLACE(sr.Storage, ' MB available space', '') AS NUMERIC) / 1024
					WHEN sr.Storage LIKE '%% GB %%' THEN CAST(REPLACE(sr.Storage, ' GB available space', '') AS NUMERIC)
				END
			) <= :storage	
	    """	
	

        cursor = g.conn.execute(text(base_query + derivative_clause + storage_clause), {'budget': budget, 'storage': storage})
        multiple_games = cursor.fetchall()
        cursor.close()
        return render_template("multiple_search_results.html", multiple_games = multiple_games)
    return redirect('/')


@app.route('/find_similar_games', methods=['POST'])
def find_similar_games():
    game_name = request.form['game_name']
    if game_name:
        similar_games_query = """
        SELECT g2.Game_Title, g2.Average_Rate_Type, g2.Current_Price, g2.Discount
            FROM ONLY Games g1
            JOIN ONLY Games g2 ON g1.Discount = g2.Discount
            WHERE g1.Average_Rate_Type = g2.Average_Rate_Type 
            AND g1.Game_Title = :game_name
            AND g1.Game_Title <> g2.Game_Title;
        """
        cursor = g.conn.execute(text(similar_games_query), {'game_name': game_name})
        similar_games = cursor.fetchall()
        print(similar_games)
        cursor.close()
        return render_template("similar_games.html", similar_games=similar_games)
    return redirect('/')


@app.route('/find_reviews', methods=['POST'])
def reviews_search():
    GameName = request.form['GameName']
    P_N = request.form['P_N']
    agreed = request.form['agreed']


    if GameName is not None:

        base_query = """
        SELECT g.Game_Title, r.ReviewText, R.Rating, R.Liked
		FROM Reviews_Ratings r
		JOIN ONLY Games g ON r.Game_id = g.Game_id
		WHERE g.Game_Title = :GameName
		""" 

        PN_clause = ""
        if P_N == "Positive":
            PN_clause = """
			AND r.Rating >= 3 AND r.Recommend = 1  
		"""
        elif P_N == "Negative":
            PN_clause = """
			AND r.Rating <= 3 AND r.Recommend = 0
		"""

        
        agreed_clause =""
        if agreed == "yes":
            agreed_clause = """
			AND r.Liked >= 50  
		"""
	

        cursor = g.conn.execute(text(base_query + PN_clause + agreed_clause), {'GameName': GameName})
        multiple_reviews = cursor.fetchall()
        cursor.close()
        return render_template("review_results.html", multiple_reviews = multiple_reviews)
    return redirect('/')


@app.route('/find_recommend_games', methods=['POST'])
def find_recommend_games():
    user_id = request.form['user_id']
    formatted_user_id = f'"{user_id}"'
    if user_id:
        similar_tags_query = """
        SELECT DISTINCT g.Game_Title
        FROM Games g
        JOIN Tags t ON g.Game_id = t.Game_id
        WHERE t.Tag IN (
            SELECT DISTINCT t1.Tag
            FROM Tags t1
            JOIN Library_Stored ls ON t1.Game_id = ls.Game_id
            WHERE ls.User_id = :user_id
        ) AND g.Game_id NOT IN (
            SELECT Game_id
            FROM Library_Stored
            WHERE User_id = :user_id
        )
        """

        same_publisher_query = """
        SELECT g.Game_Title
        FROM ONLY Games g
        WHERE g.Game_id IN (
            SELECT gp.Game_id
            FROM Games_Publishers gp
            JOIN Games_Publishers gp_user ON gp.Publisher_id = gp_user.Publisher_id
            WHERE gp_user.Game_id IN (
                SELECT Game_id
                FROM Library_Stored
                WHERE User_id = :user_id
            ) AND g.Game_id NOT IN (
                SELECT Game_id
                FROM Library_Stored
                WHERE User_id = :user_id
			)
        )
        """

        same_developer_query = """
        SELECT g.Game_Title
        FROM ONLY Games g
        WHERE g.Game_id IN (
            SELECT gd.Game_id
            FROM Games_Developers gd
            JOIN Games_Developers gd_user ON gd.Developer_id = gd_user.Developer_id
            WHERE gd_user.Game_id IN (
                SELECT Game_id
                FROM Library_Stored
                WHERE User_id = :user_id
            ) AND g.Game_id NOT IN (
                SELECT Game_id
                FROM Library_Stored
                WHERE User_id = :user_id
			)
        )
        """

        friends_games_query = """
        SELECT g.Game_Title
        FROM ONLY Games g
        WHERE g.Game_id IN (
            SELECT Game_id
            FROM Library_Stored
            WHERE User_id IN (
                SELECT friUser_id
                FROM Friended_Users
                WHERE User_id = :user_id
            ) AND g.Game_id NOT IN (
                SELECT Game_id
                FROM Library_Stored
                WHERE User_id = :user_id
			)
        )
        """
        wishlist_games_query = """
        SELECT DISTINCT g.Game_Title
        FROM ONLY Games g
        WHERE g.Game_id IN (
            SELECT Game_id
            FROM WishList_Cart
            WHERE User_id = :user_id
        )
        """
        mostLikely_like_games_query = """
        WITH All_Games AS (
            SELECT DISTINCT g.Game_Title, g.Original_Price
            FROM ONLY Games g
            JOIN Tags t ON g.Game_id = t.Game_id
            WHERE t.Tag IN (
                SELECT DISTINCT t1.Tag
                FROM Tags t1
                JOIN Library_Stored ls ON t1.Game_id = ls.Game_id
                WHERE ls.User_id = :user_id
            ) AND g.Game_id NOT IN (
                SELECT Game_id
                FROM Library_Stored
                WHERE User_id = :user_id
            )
            UNION ALL
            SELECT g.Game_Title, g.Original_Price
            FROM ONLY Games g
            WHERE g.Game_id IN (
                SELECT gp.Game_id
                FROM Games_Publishers gp
                JOIN Games_Publishers gp_user ON gp.Publisher_id = gp_user.Publisher_id
                WHERE gp_user.Game_id IN (
                    SELECT Game_id
                    FROM Library_Stored
                 WHERE User_id = :user_id
                ) AND g.Game_id NOT IN (
                    SELECT Game_id
                    FROM Library_Stored
                    WHERE User_id = :user_id
				)
            )
            UNION ALL
            SELECT g.Game_Title, g.Original_Price
            FROM ONLY Games g
            WHERE g.Game_id IN (
                SELECT gd.Game_id
                FROM Games_Developers gd
                JOIN Games_Developers gd_user ON gd.Developer_id = gd_user.Developer_id
                WHERE gd_user.Game_id IN (
                    SELECT Game_id
                    FROM Library_Stored
                    WHERE User_id = :user_id
                ) AND g.Game_id NOT IN (
                    SELECT Game_id
                    FROM Library_Stored
                    WHERE User_id = :user_id
				)
            )
            UNION ALL
            SELECT g.Game_Title, g.Original_Price
            FROM ONLY Games g
            WHERE g.Game_id IN (
                SELECT Game_id
                FROM Library_Stored
                WHERE User_id IN (
                    SELECT friUser_id
                    FROM Friended_Users
                    WHERE User_id = :user_id
                ) AND g.Game_id NOT IN (
                    SELECT Game_id
                    FROM Library_Stored
                    WHERE User_id = :user_id
				)
            )
            UNION ALL
            SELECT g.Game_Title, g.Original_Price
            FROM ONLY Games g
            WHERE g.Game_id IN (
                SELECT Game_id
                FROM WishList_Cart
                WHERE User_id = :user_id
            )
        ),
        Filtered_Games AS (
            SELECT Game_Title, Original_Price
            FROM All_Games
            
        ),
        Frequency_Counts AS (
            SELECT Game_Title, COUNT(*) AS Frequency, Original_Price
            FROM Filtered_Games
            GROUP BY Game_Title, Original_Price
        ),
        Max_Frequency AS (
            SELECT MAX(Frequency) AS MaxFreq
            FROM Frequency_Counts
        )
        SELECT f.Game_Title, f.Original_Price, 
               ROUND(f.Original_Price * 0.7, 2) AS Discounted_Price, 
               ROUND(f.Original_Price * 0.3, 2) AS Discount_Amount
        FROM Frequency_Counts f, Max_Frequency mf
        WHERE f.Frequency = mf.MaxFreq
        ORDER BY f.Game_Title
        
        """        
		#SELECT Game_Title, COUNT(*) AS Frequency
        #FROM All_Games
        #WHERE Game_Title NOT ILIKE '%Not Included%'
        #GROUP BY Game_Title
        #HAVING Frequency = MAX(Frequency)
		
        #ORDER BY Frequency DESC
        similar_tags_cursor = g.conn.execute(text(similar_tags_query), {'user_id': formatted_user_id})
        similar_tags_games = [row[0] for row in similar_tags_cursor]
        similar_tags_cursor.close()

        same_publisher_cursor = g.conn.execute(text(same_publisher_query), {'user_id': formatted_user_id})
        same_publisher_games = [row[0] for row in same_publisher_cursor]
        same_publisher_cursor.close()

        same_developer_cursor = g.conn.execute(text(same_developer_query), {'user_id': formatted_user_id})
        same_developer_games = [row[0] for row in same_developer_cursor]
        same_developer_cursor.close()

        friends_games_cursor = g.conn.execute(text(friends_games_query), {'user_id': formatted_user_id})
        friends_games = [row[0] for row in friends_games_cursor]
        friends_games_cursor.close()

        wishlist_cursor = g.conn.execute(text(wishlist_games_query), {'user_id': formatted_user_id})
        wishlist_games = [row[0] for row in wishlist_cursor]
        wishlist_cursor.close()
		
        mostLikely_like_cursor = g.conn.execute(text(mostLikely_like_games_query), {'user_id': formatted_user_id})
        mostLikely_like_games = [{
            'title': row[0],  
            'original_price': row[1], 
            'discounted_price': row[2],
            'discount_amount': row[3]
        } for row in mostLikely_like_cursor]
        mostLikely_like_cursor.close()


        return render_template("recommend_games.html", 
                               similar_tags_games=similar_tags_games, 
                               same_publisher_games=same_publisher_games, 
                               same_developer_games=same_developer_games, 
                               friends_games=friends_games,
							   wishlist_games=wishlist_games,
							   mostLikely_like_games=mostLikely_like_games)
    return redirect('/')




@app.route('/game_recommendation_discount')
def game_recommendation_discount():
    return render_template("useridLogin.html")


@app.route('/reviews_rating_query')
def reviews_rating_query():
    return render_template("review_search.html")


@app.route('/similar_games_query')
def similar_games_query():
    return render_template("game_query.html")


@app.route('/developer_type_query')
def developer_type_query():
    return render_template("developer_type_query.html")


@app.route('/multiple_input_games')
def multiple_input_games():
    return render_template("multiple_search.html")\
    



@app.route('/')
def index():
    return render_template("index.html")



if __name__ == "__main__":
	import click

	@click.command()
	@click.option('--debug', is_flag=True)
	@click.option('--threaded', is_flag=True)
	@click.argument('HOST', default='0.0.0.0')
	@click.argument('PORT', default=8111, type=int)
	def run(debug, threaded, host, port):
		"""
		This function handles command line parameters.
		Run the server using:

			python server.py

		Show the help text using:

			python server.py --help

		"""

		HOST, PORT = host, port
		print("running on %s:%d" % (HOST, PORT))
		app.run(host=HOST, port=PORT, debug=debug, threaded=threaded)

run()